# FileSocket
##### A server that storages files and the client can download them

## Built With

- Java

## Members

- **Lorenzo Sanseverino**
- **Valerio Gallo**

## 🤝 Support
We really hope that this is a good program and maybe give us a good mark --> 10 ❤️❤️❤️❤️❤️❤️